"use strict";(()=>{var a={};a.id=47,a.ids=[47],a.modules={399:a=>{a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:a=>{a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},9479:(a,e,t)=>{t.r(e),t.d(e,{originalPathname:()=>w,patchFetch:()=>f,requestAsyncStorage:()=>g,routeModule:()=>k,serverHooks:()=>y,staticGenerationAsyncStorage:()=>b});var n={};t.r(n),t.d(n,{GET:()=>c,POST:()=>d});var i=t(3278),s=t(5002),r=t(4877);let u="39d95b59-1c49-81ac-b7d7-cff618972925",o="2022-06-28";async function l(a,e){try{let t=process.env.DEEPSEEK_API_KEY||"";if(!t||t.length<10)return null;console.log("[AI] Calling DeepSeek with key length:",t.length);let n=`Kamu adalah Admin Komunitas Tumbuh Bersama — asisten Ika Irawati.

IDENTITAS:
- Kamu BUKAN AI bot — kamu bagian dari tim Komunitas
- Bicara comme sesama ibu, pakai "Bunda"
- Hangat, santai, gak jualan, gak pressure
- Boleh ceplas-ceplos kayak teman ngobrol

PANDUAN JAWAB:
- Jawab PERTANYAAN user secara langsung dulu, baru arahkan ke program
- Contoh: user tanya "caranya submit tugas?" → jawab dulu caranya, baru kalau relevan arahkan
- JANGAN paksa redirect ke program kalau user cuma tanya sesuatu
- Jawab dengan alami, kayak chat sama teman, bukan template marketing
- Maks 200 karakter. Santai. Natural.

KONTEKS USER:
${e}

LARANGAN:
- Jangan kasih janji penghasilan pasti
- Jangan pressure
- Jangan bahas politik/agama/SARA
- Jangan saran kesehatan/medis`,i=await fetch("https://api.deepseek.com/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${t}`,"Content-Type":"application/json"},body:JSON.stringify({model:"deepseek-chat",messages:[{role:"system",content:n},{role:"user",content:a}],max_tokens:200,temperature:.7})});if(!i.ok)return null;let s=await i.json();return s?.choices?.[0]?.message?.content?.trim()||null}catch{return null}}async function p(a){let e=process.env.NOTION_TOKEN||"";if(!e)return null;try{let t=await fetch(`https://api.notion.com/v1/databases/${u}/query`,{method:"POST",headers:{Authorization:`Bearer ${e}`,"Notion-Version":o,"Content-Type":"application/json"},body:JSON.stringify({filter:{property:"Lead Name",title:{contains:a}}})}),n=await t.json();return n.results?.[0]||null}catch(a){return null}}async function m(a,e){let t=process.env.NOTION_TOKEN||"";if(t)try{await fetch("https://api.notion.com/v1/pages",{method:"POST",headers:{Authorization:`Bearer ${t}`,"Notion-Version":o,"Content-Type":"application/json"},body:JSON.stringify({parent:{database_id:u},properties:{"Lead Name":{title:[{text:{content:`${a}`}}]},"Day 1":{checkbox:!1},Completed:{checkbox:!1},"Completion Rate":{number:0}}})})}catch(a){}}async function h(a,e){let t=process.env.NOTION_TOKEN||"";if(t)try{await fetch(`https://api.notion.com/v1/pages/${a}`,{method:"PATCH",headers:{Authorization:`Bearer ${t}`,"Notion-Version":o,"Content-Type":"application/json"},body:JSON.stringify(e)})}catch(a){}}async function d(a){try{var e;let t=await a.text(),n={};try{n=JSON.parse(t)}catch{}let i=(n?.message||"").trim(),s=n?.phone||"";if(!s||!i)return new Response(null,{status:204});let r=i.toLowerCase().trim();if(["ok","oke","okay","oh","ohh","owh","ya udah","sip","noted","baik","baik2","bae","hmm","hm","he eh","yoi"].some(a=>r===a||r.startsWith(a)))return new Response(null,{status:204});await (e=8e3+7e3*Math.random(),new Promise(a=>setTimeout(a,e)));let u=await p(s);if(u){let a=u.properties||{},e=a["Lead Name"]?.title?.[0]?.text?.content||"";if(a["Day 1"]?.checkbox===!0){let a=await l(i,"User sudah selesai Day 1, menunggu Day 2.");if(a)return new Response(a);return new Response(`Halo Bunda! Besok jam 7 pagi kita lanjut Day 2 ya! Semangat! 🌸`)}let t=e.split("||");if(1===t.length&&!e.includes("—")){let a=`${s} — ${i}`;await h(u.id,{properties:{"Lead Name":{title:[{text:{content:a}}]}}});let e=i.split(" ")[0];return new Response(`Senang berkenalan, ${e}! 🌸 Nama yang cantik.

Bunda tinggal di kota mana?`)}if(1===t.length){let a=`${e} || city: ${i}`;return await h(u.id,{properties:{"Lead Name":{title:[{text:{content:a}}]}}}),new Response(`Wah, pasti kota yang indah! 🌸

Boleh cerita, apa yang membuat Bunda tertarik ikut challenge ini? Tujuannya apa?`)}if(2===t.length){let a=`${e} || goal: ${i}`;return await h(u.id,{properties:{"Lead Name":{title:[{text:{content:a}}]}}}),new Response(`Wah, itu keren banget Bunda! 👏 Saya bisa rasain semangatnya dari sini.

Tujuan seperti itu sejalan banget dengan visi komunitas kita. Saya yakin Bunda bisa mencapai itu.

Bunda kenal Komunitas Tumbuh Bersama dari mana? IG, TikTok, atau dari teman?`)}if(3===t.length){let a=`${e} || source: ${i}`;return await h(u.id,{properties:{"Lead Name":{title:[{text:{content:a}}]},"Day 1":{checkbox:!0},"Completion Rate":{number:14.29}}}),new Response(`🎉 Terima kasih Bunda! Sekarang Bunda resmi bergabung di 7 Hari Memulai Perubahan.

Langkah pertama adalah yang terberat, dan Bunda sudah melakukannya. Saya bangga! 👏

📚 *Day 1: Mulai dari Dalam* — bersama Ika Irawati
✅ Tulis 2 hal yang disyukuri hari ini
✅ Tulis 1 keterampilan baru yang ingin Bunda kuasai
✅ Balas: *Saya Siap Bertumbuh*

Kerjakan dulu ya Bunda, santai aja. Besok kita lanjut Day 2! 🚀`)}}if(["ya","iya","siap","mau","ikut","daftar","join","gabung","coba","tes","test","tertarik","pingin","pengen","ingin","belajar","mulai","lanjut","saya mau","saya ingin","saya pengen","mau dong","ayo","gas","yuk"].some(a=>r===a||r.startsWith(a)||r.includes(a)))return await m(s,n?.pushName||""),new Response("Senang sekali Bunda tertarik! \uD83C\uDF38\n\nSebelum mulai, saya mau kenalan dulu ya.\n\nSiapa nama lengkap Bunda?");if(["hai","halo","hello","hi","hey","selamat","pagi","siang","sore","malam","assalamualaikum","asslm"].some(a=>r.includes(a)))return await m(s,n?.pushName||""),new Response(`Halo Bunda! 👋 Selamat datang di Komunitas Tumbuh Bersama.

Kami punya program 7 Hari Memulai Perubahan — GRATIS. Dirancang khusus untuk ibu-ibu hebat seperti Bunda.

Sebelum mulai, saya mau kenalan dulu ya.

Siapa nama lengkap Bunda? 🌸`);if(["stop","berhenti","cancel","batal","keluar"].some(a=>r.includes(a)))return new Response("Kamu berhenti menerima broadcast. Ketik MULAI kapan saja untuk bergabung kembali");if(["tanya","help","bantu","info","faq","apa itu","bagaimana"].some(a=>r.includes(a)))return new Response("Info — 7 Hari Memulai Perubahan\n\n❓ Apa ini? Program 7 hari GRATIS untuk bangun mindset leadership dan mulai perubahan kecil setiap hari.\n\uD83D\uDCB0 Gratis 100%.\n\uD83D\uDC65 Join komunitas khusus member.\n\nKetik YA untuk daftar!");let o="",d="User baru, belum kenal komunitas.";if(u){let a=u.properties?.Notes?.rich_text?.[0]?.text?.content||"";a&&(o=`

Riwayat chat:
${a}`);let e=u.properties||{},t=e["Lead Name"]?.title?.[0]?.text?.content||"";d=e["Day 1"]?.checkbox===!0?"User sudah selesai Day 1, menunggu Day 2. Boleh jawab pertanyaan seputar program.":t.includes("||source:")?"User baru isi data lengkap, siap mulai Day 1.":t.includes("||")?"User sedang isi data pendaftaran.":"User sudah daftar, tahap awal."}let c=await l(i,`${d}${o}`);if(c){if(u){let a=u.properties?.Notes?.rich_text?.[0]?.text?.content||"",e=(a?a+"\n":"")+`[Q: ${i}] [A: ${c}]`,t=e.length>1900?e.slice(-1900):e;h(u.id,{properties:{Notes:{rich_text:[{text:{content:t}}]}}}).catch(()=>{})}return new Response(c)}return new Response(`Halo Bunda! Selamat datang di Komunitas Tumbuh Bersama. Ada yang bisa dibantu? 😊`)}catch(a){return console.error("[WEBHOOK]",a.message),new Response(null,{status:204})}}async function c(){return new Response("Webhook active")}let k=new i.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/wablas-webhook/route",pathname:"/api/wablas-webhook",filename:"route",bundlePath:"app/api/wablas-webhook/route"},resolvedPagePath:"/home/ubuntu/growwithika/src/app/api/wablas-webhook/route.ts",nextConfigOutput:"standalone",userland:n}),{requestAsyncStorage:g,staticGenerationAsyncStorage:b,serverHooks:y}=k,w="/api/wablas-webhook/route";function f(){return(0,r.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:b})}},3278:(a,e,t)=>{a.exports=t(517)}};var e=require("../../../webpack-runtime.js");e.C(a);var t=a=>e(e.s=a),n=e.X(0,[379],()=>t(9479));module.exports=n})();